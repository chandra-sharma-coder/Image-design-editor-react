export { default as Title } from './Title';

export { default as Content } from './Content';
