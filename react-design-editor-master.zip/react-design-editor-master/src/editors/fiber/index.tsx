import FiberEditor from './FiberEditor';

export default FiberEditor;
