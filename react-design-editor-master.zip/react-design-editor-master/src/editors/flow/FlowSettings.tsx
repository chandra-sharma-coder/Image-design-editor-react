import React from 'react';

const FlowSettings = () => {
	return (
		<div className="flow-editor-settings">
			<div>Settings</div>
		</div>
	);
};

export default FlowSettings;
