import React from 'react';

const FlowToolbar = () => {
	return <div className="flow-editor-toolbar-wrapper"></div>;
};

export default FlowToolbar;
