import ImageMapEditor from './ImageMapEditor';

export default ImageMapEditor;
