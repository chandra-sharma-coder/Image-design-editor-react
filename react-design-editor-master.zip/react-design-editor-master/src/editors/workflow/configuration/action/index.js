import DebugNodeConfiguration from './DebugNodeConfiguration';
import EmailNodeConfiguration from './EmailNodeConfiguration';

export default {
	DebugNode: DebugNodeConfiguration,
	EmailNode: EmailNodeConfiguration,
};
