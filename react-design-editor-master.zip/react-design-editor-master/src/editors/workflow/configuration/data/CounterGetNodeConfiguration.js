export default {
	keyTemplate: {
		type: 'template',
		icon: '',
		label: 'KeyTemplate',
	},
	resultPath: {
		type: 'text',
		icon: '',
		label: 'ResultPath',
	},
};
