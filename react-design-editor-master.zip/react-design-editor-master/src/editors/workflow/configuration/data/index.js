import CounterGetNodeConfiguration from './CounterGetNodeConfiguration';
import CounterSetNodeConfiguration from './CounterSetNodeConfiguration';

export default {
	CounterGetNode: CounterGetNodeConfiguration,
	CounterSetNode: CounterSetNodeConfiguration,
};
