export default {
	jsScript: {
		type: 'script',
		required: true,
		icon: '',
		label: 'JSscript',
		span: 24,
	},
};
