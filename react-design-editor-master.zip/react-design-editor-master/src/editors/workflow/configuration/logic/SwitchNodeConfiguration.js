export default {
	routes: {
		type: 'tags',
		required: true,
		icon: '',
		label: 'Routes',
		span: 24,
	},
	jsScript: {
		type: 'script',
		required: true,
		icon: '',
		label: 'JSscript',
		span: 24,
	},
};
