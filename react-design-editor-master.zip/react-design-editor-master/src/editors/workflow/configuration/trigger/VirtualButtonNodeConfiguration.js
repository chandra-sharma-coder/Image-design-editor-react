export default {
	payload: {
		type: 'json',
		icon: '',
		required: true,
		default: '',
		label: 'Payload',
	},
};
