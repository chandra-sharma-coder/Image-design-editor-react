export { default as i18nClient } from './i18nClient';
