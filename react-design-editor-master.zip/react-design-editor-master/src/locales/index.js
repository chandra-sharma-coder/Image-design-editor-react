import translationKo from './locale.constant-ko.json';
import translation from './locale.constant.json';

export { translationKo, translation };
